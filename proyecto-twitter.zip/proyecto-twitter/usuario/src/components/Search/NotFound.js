import React from 'react'


const NotFound = () => (<h2 style={{ textAlign: 'center' }}>
		User not found
	</h2>)

export default NotFound